//
//  ViewController.swift
//  SegmentControl
//
//  Created by Patel, Nirali Arvindbhai on 9/9/19.
//  Copyright © 2019 Patel, Nirali Arvindbhai. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITextFieldDelegate{

    
    @IBOutlet weak var segmentNumberSystem: UISegmentedControl!
    
    @IBOutlet weak var txtInputValue: UITextField!
    
    
    @IBOutlet weak var lblop1: UILabel!
    
    @IBOutlet weak var lblop2: UILabel!
    
    @IBOutlet weak var lblop3: UILabel!
    
    
    @IBOutlet weak var txtop1: UITextField!
    
    @IBOutlet weak var txtop2: UITextField!
    
    @IBOutlet weak var txtop3: UITextField!
    
   
    
    @IBAction func seg(_ sender: UISegmentedControl) {
        
        if segmentNumberSystem.selectedSegmentIndex == 0
        {
            lblop1.text = "Binary"
            lblop2.text = "Octal"
            lblop3.text = "Hexadecimal"
            
        }
        else if segmentNumberSystem.selectedSegmentIndex == 1
        {
            lblop1.text = "Decimal"
            lblop2.text = "Octal"
            lblop3.text = "Hexadecimal"
        }
        else if segmentNumberSystem.selectedSegmentIndex == 2
        {
            lblop1.text = "Decimal"
            lblop2.text = "Binary"
            lblop3.text = "Hexadecimal"
        }
        else if segmentNumberSystem.selectedSegmentIndex == 3
        {
            lblop1.text = "Decimal"
            lblop2.text = "Binary"
            lblop3.text = "Octal"
        }
    }
    
    
    @IBAction func btnConvert(_ sender: Any) {
        
        
    //    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
      //      txtInputValue.becomeFirstResponder()
       // }
        var va = ""
         va = txtInputValue.text!
        let val = Int(va)
      //  let val = String(va!)
        
        //let val:Int = txtInputValue.text!
        
        //txtInputValue.text = NSString(format: "val: %i", val) as String
      /// let val : int? = self.txtInputValue.text.toInt()
        
        
       // let text : String = "12345"
       // var digits = [Int]()
      //  for element in text.characters {
       //     digits.append(Int(String(element))!)
       // }
        
        
   // let v = 1000
        
      if segmentNumberSystem.selectedSegmentIndex == 0
       {
        
        lblop1.text = "Binary"
        lblop2.text = "Octal"
        lblop3.text = "Hexadecimal"
    //    let D2B = "0"
     //       if let temp = val {
      //          let D2B = String(temp, radix: 2)
        //    }
        var va = ""
        va = txtInputValue.text!
        let val = Int(va)
        let D2B = String(val!, radix: 2)
        let D2O = String(val! , radix:8)
        let D2H = String(val! , radix: 16)
            
           txtop1.text = D2B
            txtop2.text = D2O
            txtop3.text = D2H + "H"
        }
        
        else if segmentNumberSystem.selectedSegmentIndex == 1
        {
            lblop1.text = "Decimal"
            lblop2.text = "Octal"
            lblop3.text = "Hexadecimal"
            
            var a = ""
            a = txtInputValue.text!
           // let  b = Int(a)
            
        let B2D = Int(a , radix: 2)
            let B2O = String(B2D! , radix: 8)
        let B2H = String(B2D!, radix: 16)
            txtop1.text = "\(B2D!)"
            txtop2.text = B2O
            txtop3.text = B2H
        }
        
        else if segmentNumberSystem.selectedSegmentIndex == 2
        {
            
            lblop1.text = "Decimal"
            lblop2.text = "Binary"
            lblop3.text = "Hexadecimal"
            var p = ""
            p = txtInputValue.text!
            
        let O2D = Int(p , radix: 8)
        let O2B = String(O2D! , radix:2)
        let O2H = String(O2D! , radix: 16)
            txtop1.text = "\(O2D!)"
            txtop2.text = O2B
            txtop3.text = O2H
        }
        
        else if segmentNumberSystem.selectedSegmentIndex == 3
        {
            
            lblop1.text = "Decimal"
            lblop2.text = "Binary"
            lblop3.text = "Octal"
            var x = ""
            x = txtInputValue.text!
            
            
        let H2D = Int(x , radix: 16)
        let H2B = String(H2D! ,radix: 2)
        let H2O = String(H2D! , radix: 8)
        txtop1.text = "\(H2D!)"
        txtop2.text = H2B
        txtop3.text = H2O
        }
        
    }
    
    
    
    @IBAction func btnClear(_ sender: Any) {
        txtop1.text = nil
        txtop2.text = nil
        txtop3.text = nil
        txtInputValue.text = nil
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        
       
        // Do any additional setup after loading the view.
    }
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        txtInputValue.resignFirstResponder()
        return true
    }

}

